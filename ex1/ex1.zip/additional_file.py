def secret_function():
    print("My username is 'daniel.rez' and I found the string '1lXDAtTpoKUH' in the submission response.")
